public class Main {

	public static void main(String[] args) {
                 
               Scanner a=new Scanner(System.in);
               Student students=new Student();
               int size;
               System.out.println("enter the no of students:");
               size=a.nextInt();
               Student[] b=new Student[size];
               int id;
               string fullName;
               Date birthDate;
               double avgMark;
                  
                 Student s;
               
		
		//You may test that your code works find here
		//Please check that your code works and has no 
		//compilation problems before to submit
	}

}
